"""Data models for the gen_landing Lambda."""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import re


@dataclass
class ThemeInfo:
    """Theme information extracted from the target website."""
    
    fonts: List[str] = field(default_factory=list)
    color_palette: List[str] = field(default_factory=list)
    logo_url: Optional[str] = None
    layout_hints: Dict[str, Any] = field(default_factory=dict)
    inline_styles: List[str] = field(default_factory=list)
    css_links: List[str] = field(default_factory=list)
    favicon_url: Optional[str] = None
    hero_image_url: Optional[str] = None
    
    def __post_init__(self):
        """Validate and clean up fields after initialization."""
        # Clean fonts
        if self.fonts:
            self.fonts = [font.strip() for font in self.fonts if font and font.strip()]
        
        # Clean colors
        if self.color_palette:
            valid_colors = []
            for color in self.color_palette:
                if color and isinstance(color, str) and (color.startswith('#') or color.startswith('rgb')):
                    valid_colors.append(color.strip())
            self.color_palette = valid_colors
        
        # Clean CSS links
        if self.css_links:
            self.css_links = [link.strip() for link in self.css_links if link and link.strip()]


@dataclass
class LandingContent:
    """Generated landing page content structure."""
    
    hero_html: str
    features_html: str
    cta_html: str
    img_prompts: List[str]
    
    def __post_init__(self):
        """Validate and clean up fields after initialization."""
        # Validate HTML content
        for field_name in ['hero_html', 'features_html', 'cta_html']:
            value = getattr(self, field_name)
            if not value or not value.strip():
                raise ValueError(f"{field_name} cannot be empty")
            
            # Auto-add lp- prefix to generic classes if needed
            if 'class=' in value and 'lp-' not in value:
                value = re.sub(r'class="([^"]*)"', lambda m: f'class="lp-{m.group(1)}"', value)
            
            setattr(self, field_name, value.strip())
        
        # Clean image prompts
        if self.img_prompts:
            self.img_prompts = [prompt.strip() for prompt in self.img_prompts if prompt and prompt.strip()]


@dataclass
class GenerationRequest:
    """Request structure for landing page generation."""
    
    prompt: str
    theme_info: Optional[ThemeInfo] = None
    
    def __post_init__(self):
        """Validate prompt after initialization."""
        if not self.prompt or not self.prompt.strip():
            raise ValueError("Prompt cannot be empty")
        
        # Basic sanitization
        self.prompt = self.prompt.strip()
        if len(self.prompt) < 3:
            raise ValueError("Prompt must be at least 3 characters")
        
        # Remove potentially harmful content
        self.prompt = re.sub(r'<script[^>]*>.*?</script>', '', self.prompt, flags=re.IGNORECASE | re.DOTALL)
        self.prompt = re.sub(r'javascript:', '', self.prompt, flags=re.IGNORECASE)


@dataclass
class GenerationResponse:
    """Response structure for landing page generation."""
    
    generation_id: str
    assets: Dict[str, str]
    status: str
    
    def __post_init__(self):
        """Validate status after initialization."""
        valid_statuses = ['generated', 'failed', 'in_progress']
        if self.status not in valid_statuses:
            raise ValueError(f"Status must be one of: {valid_statuses}")


@dataclass
class BedrockPayload:
    """Bedrock API payload structure for Claude 3 Messages API."""
    
    messages: List[Dict[str, Any]]
    anthropic_version: str = "bedrock-2023-05-31"
    max_tokens: int = 1024
    temperature: float = 0.7
    system: Optional[str] = None
    
    def __post_init__(self):
        """Validate fields after initialization."""
        if self.max_tokens < 100 or self.max_tokens > 4000:
            raise ValueError("Max tokens must be between 100 and 4000")
        
        if self.temperature < 0.0 or self.temperature > 1.0:
            raise ValueError("Temperature must be between 0.0 and 1.0")


@dataclass
class SSMPrompts:
    """SSM parameter prompts structure."""
    
    system_prompt: str
    prompt_template: str
    
    def __post_init__(self):
        """Validate prompts after initialization."""
        if not self.system_prompt or not self.system_prompt.strip():
            raise ValueError("System prompt cannot be empty")
        if not self.prompt_template or not self.prompt_template.strip():
            raise ValueError("Prompt template cannot be empty")
        
        self.system_prompt = self.system_prompt.strip()
        self.prompt_template = self.prompt_template.strip()


@dataclass
class BedrockResponse:
    """Bedrock API response structure for Claude 3 Messages API."""
    
    content: List[Dict[str, Any]]
    model: str
    usage: Dict[str, int]
    role: str = "assistant"
    stop_reason: Optional[str] = None
    stop_sequence: Optional[str] = None
    id: Optional[str] = None
    type: Optional[str] = None
    
    def __post_init__(self):
        """Validate content after initialization."""
        if not self.content:
            raise ValueError("Content cannot be empty") 