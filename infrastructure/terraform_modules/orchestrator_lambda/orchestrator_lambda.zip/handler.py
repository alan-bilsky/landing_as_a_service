"""Lambda handler for orchestrator - coordinates the three-step workflow."""

import json
import os
import uuid
import base64
import time
import sys

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.utilities.typing import LambdaContext

# Initialize Powertools
logger = Logger()
tracer = Tracer()
metrics = Metrics()

lambda_client = boto3.client('lambda')

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST"
}

# Environment variables for target Lambda ARNs or names
FETCH_SITE_LAMBDA = os.environ.get('FETCH_SITE_LAMBDA_NAME', 'laas-prod-fetch-site')
GEN_LANDING_LAMBDA = os.environ.get('GEN_LANDING_LAMBDA_NAME', 'laas-prod-gen-landing')
INJECT_HTML_LAMBDA = os.environ.get('INJECT_HTML_LAMBDA_NAME', 'laas-prod-inject-html')

print("Python version:", sys.version)
print("sys.path:", sys.path)

@tracer.capture_method
def invoke_lambda(function_name, payload):
    """Invoke a Lambda function and return the parsed response."""
    try:
        logger.info(f"Invoking {function_name}", extra={"payload": payload})
        
        response = lambda_client.invoke(
            FunctionName=function_name,
            InvocationType='RequestResponse',
            Payload=json.dumps(payload)
        )
        
        response_body = response['Payload'].read().decode('utf-8')
        logger.info(f"{function_name} response received", extra={"response_length": len(response_body)})
        
        # Parse the response
        try:
            result = json.loads(response_body)
        except json.JSONDecodeError as e:
            logger.error(f"{function_name} returned invalid JSON", extra={"response": response_body, "error": str(e)})
            raise ValueError(f"{function_name} returned invalid JSON: {str(e)}")
        
        # Check for Lambda errors
        status_code = result.get('statusCode')
        if status_code != 200:
            error_msg = result.get('body', 'Unknown error')
            if isinstance(error_msg, str):
                try:
                    error_body = json.loads(error_msg)
                    error_msg = error_body.get('error', error_msg)
                except json.JSONDecodeError:
                    logger.warning(f"Could not parse error body as JSON: {error_msg}")
                    # If it's not JSON, use the string as is
                    pass
            
            # Log the full error details for debugging
            logger.error(f"{function_name} failed", extra={
                "status_code": status_code,
                "error_message": error_msg,
                "full_response": result
            })
            raise RuntimeError(f"{function_name} failed: {error_msg}")
        
        # Parse the body if it's a string (API Gateway format)
        body = result.get('body')
        if isinstance(body, str):
            try:
                body = json.loads(body)
                logger.info(f"{function_name} body parsed successfully", extra={"body_keys": list(body.keys()) if isinstance(body, dict) else None})
            except json.JSONDecodeError as e:
                logger.error(f"{function_name} body is not valid JSON", extra={"body": body, "error": str(e)})
                raise ValueError(f"{function_name} returned invalid JSON body: {str(e)}")
        
        return body
        
    except Exception as e:
        logger.error(f"Error invoking {function_name}", extra={"error": str(e)})
        raise

@logger.inject_lambda_context
@tracer.capture_lambda_handler
@metrics.log_metrics
def handler(event, context: LambdaContext):
    """Orchestrate the three-step workflow: fetch_site → gen_landing → inject_html."""
    
    logger.info("Orchestrator Lambda invoked")
    
    try:
        # Parse input
        if "body" in event:
            body_content = event["body"]
            if event.get("isBase64Encoded"):
                body_content = base64.b64decode(body_content).decode("utf-8")
            parsed = json.loads(body_content)
        else:
            parsed = event if isinstance(event, dict) else json.loads(event)
        
        source_url = parsed.get('source_url')
        prompt = parsed.get('prompt')
        
        if not source_url or not prompt:
            return {
                "statusCode": 400,
                "headers": CORS_HEADERS,
                "body": json.dumps({"error": "Missing source_url or prompt parameter"})
            }
        
        # Generate a unique ID for this workflow
        workflow_id = str(uuid.uuid4())
        logger.info("Starting workflow", extra={"workflow_id": workflow_id, "source_url": source_url, "prompt": prompt})
        
        # Step 1: fetch_site - Download target HTML/CSS to S3 raw/ prefix
        logger.info("Step 1: Fetching site", extra={"workflow_id": workflow_id})
        fetch_payload = {"url": source_url}
        fetch_result = invoke_lambda(FETCH_SITE_LAMBDA, fetch_payload)
        
        theme_info = fetch_result.get('theme_info', {})
        s3_keys = fetch_result.get('s3_keys', {})
        
        logger.info("Site fetched successfully", extra={
            "workflow_id": workflow_id,
            "theme_info_keys": list(theme_info.keys()),
            "s3_keys": s3_keys
        })
        
        # Step 2: gen_landing - Generate landing content using Bedrock
        logger.info("Step 2: Generating landing content", extra={"workflow_id": workflow_id})
        gen_payload = {
            "prompt": prompt,
            "theme_info": theme_info
        }
        gen_result = invoke_lambda(GEN_LANDING_LAMBDA, gen_payload)
        
        generation_id = gen_result.get('generation_id')
        assets = gen_result.get('assets', {})
        
        logger.info("Landing content generated successfully", extra={
            "workflow_id": workflow_id,
            "generation_id": generation_id,
            "assets": assets
        })
        
        # Step 3: inject_html - Merge original + landing, write to public/ prefix
        logger.info("Step 3: Injecting HTML", extra={"workflow_id": workflow_id})
        inject_payload = {
            "generation_id": generation_id,
            "s3_keys": s3_keys
        }
        inject_result = invoke_lambda(INJECT_HTML_LAMBDA, inject_payload)
        
        html_url = inject_result.get('htmlUrl')
        public_key = inject_result.get('public_key')
        
        logger.info("HTML injection completed successfully", extra={
            "workflow_id": workflow_id,
            "html_url": html_url,
            "public_key": public_key
        })
        
        # Return the final result
        result = {
            "htmlUrl": html_url,
            "generation_id": generation_id,
            "workflow_id": workflow_id,
            "status": "completed"
        }
        
        return {
            "statusCode": 200,
            "headers": CORS_HEADERS,
            "body": json.dumps(result)
        }
        
    except Exception as e:
        logger.error("Error in orchestrator Lambda", extra={"error": str(e), "traceback": str(e.__traceback__)})
        return {
            "statusCode": 500,
            "headers": CORS_HEADERS,
            "body": json.dumps({"error": f"Orchestration failed: {str(e)}"})
        } 