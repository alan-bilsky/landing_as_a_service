"""Lambda handler for inject_html - merges original + landing content and writes to the public/ prefix as specified in the project rules."""

import json
import os
import uuid
import base64
import time
import re
from bs4 import BeautifulSoup
from bs4.element import Tag
from typing import Dict, Any, List

import boto3
from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.utilities.typing import LambdaContext
import urllib.parse
import urllib.request

# Initialize Powertools
logger = Logger()
tracer = Tracer()
metrics = Metrics()

s3_client = boto3.client("s3")
cloudfront_client = boto3.client("cloudfront")

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "OPTIONS,POST"
}

@tracer.capture_method
def get_s3_object(bucket, key):
    """Retrieve an object from S3."""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        return response['Body'].read().decode('utf-8')
    except Exception as e:
        logger.error(f"Failed to get S3 object {bucket}/{key}", extra={"error": str(e)})
        raise

@tracer.capture_method
def inject_landing_into_html(original_html, landing_content, theme_info):
    """Inject the generated landing content into the original HTML following project rules."""
    
    # Handle empty or invalid HTML by creating a basic template
    if not original_html or len(original_html.strip()) < 50:
        logger.warning("Original HTML is empty or too small, creating fallback template")
        original_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generated Landing Page</title>
</head>
<body>
    <main>
        <h1>Welcome</h1>
        <p>This is a generated landing page.</p>
    </main>
</body>
</html>"""
    
    soup = BeautifulSoup(original_html, "html.parser")
    
    # Create the landing section HTML
    landing_html = f"""
    <div class="lp-landing-section">
        {landing_content.get('hero_html', '')}
        {landing_content.get('features_html', '')}
        {landing_content.get('cta_html', '')}
    </div>
    """
    
    # Define CSS for landing page styling
    landing_page_css = """
        .lp-landing-section {
            width: 100%;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
        }
        
        .lp-hero {
            text-align: center;
            padding: 60px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            margin-bottom: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            position: relative;
            overflow: hidden;
        }
        
        .lp-hero h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
            font-weight: 700;
        }
        
        .lp-hero p {
            font-size: 1.2em;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .lp-button {
            display: inline-block;
            background: #ff6b6b;
            color: white;
            padding: 15px 30px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        
        .lp-button:hover {
            background: #ff5252;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .lp-features {
            margin: 40px 0;
        }
        
        .lp-feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        
        .lp-feature {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .lp-feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        
        .lp-feature h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        
        .lp-feature p {
            color: #666;
            margin: 0;
        }
        
        .lp-cta {
            background: #f8f9fa;
            padding: 50px 20px;
            text-align: center;
            border-radius: 12px;
            margin-top: 40px;
        }
        
        .lp-cta h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 2em;
        }
        
        .lp-cta p {
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1em;
        }
        
        .lp-form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            max-width: 500px;
            margin: 0 auto;
        }
        
        .lp-form input[type="email"] {
            flex: 1;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 25px;
            font-size: 16px;
            min-width: 250px;
        }
        
        .lp-form input[type="email"]:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .lp-logo {
            max-height: 60px;
            margin-bottom: 20px;
        }
        
        .lp-feature-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .lp-cta-image {
            width: 100%;
            max-width: 400px;
            height: 200px;
            object-fit: cover;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .lp-hero h1 {
                font-size: 2em;
            }
            
            .lp-hero p {
                font-size: 1.1em;
            }
            
            .lp-feature-grid {
                grid-template-columns: 1fr;
            }
            
            .lp-form {
                flex-direction: column;
            }
            
            .lp-form input[type="email"] {
                min-width: 100%;
            }
        }
    """
    
    landing_soup = BeautifulSoup(landing_html, "html.parser")
    landing_div = landing_soup.find('div', class_='lp-landing-section')
    
    if not landing_div:
        logger.warning("No landing div found in generated content")
        return original_html
    
    # Apply theme-specific styling
    if isinstance(landing_div, Tag):
        if theme_info.get('fonts'):
            primary_font = theme_info['fonts'][0] if theme_info['fonts'] else 'Arial, sans-serif'
            current_style = landing_div.get('style', '')
            landing_div['style'] = f"font-family: {primary_font}; {current_style}"
        
        if theme_info.get('color_palette'):
            primary_color = theme_info['color_palette'][0] if theme_info['color_palette'] else '#333'
            current_style = landing_div.get('style', '')
            landing_div['style'] = f"{current_style} color: {primary_color};"
    
    # Find injection point following project rules
    injection_point = None
    
    # Rule 1: Look for <header> and inject immediately after
    header = soup.find('header')
    if header:
        injection_point = header
        insert_after = True
    else:
        # Rule 2: Inject before closing </body>
        body = soup.find('body')
        if body:
            injection_point = body
            insert_after = False
    
    if injection_point:
        if insert_after:
            injection_point.insert_after(landing_div)
        else:
            injection_point.append(landing_div)
    else:
        # Fallback: append to body
        body = soup.find('body')
        if body:
            body.append(landing_div)
        else:
            # Last resort: append to html
            html_tag = soup.find('html')
            if html_tag:
                html_tag.append(landing_div)
    
    # Add landing page CSS styles
    head = soup.find('head')
    if head:
        style_tag = soup.new_tag('style')
        style_tag['id'] = "lp-landing-styles"
        style_tag.string = landing_page_css
        head.append(style_tag)
    
    # Add theme-specific CSS with lp- prefixed classes
    if theme_info.get('inline_styles'):
        # Process CSS to ensure lp- prefix for custom classes
        css_content = '\n'.join(theme_info['inline_styles'])
        
        # Add lp- prefix to any custom classes that don't already have it
        import re
        css_content = re.sub(r'\.(?!lp-)([a-zA-Z][\w-]*)', r'.lp-\1', css_content)
        
        theme_style_tag = soup.new_tag('style')
        theme_style_tag.string = css_content
        
        # Avoid duplicate style tags by checking if we already have similar styles
        if head:
            existing_styles = [style.string for style in head.find_all('style') if style.string]
            if css_content not in existing_styles:
                theme_style_tag['id'] = f"lp-theme-styles-{str(uuid.uuid4())[:8]}"
                head.append(theme_style_tag)
    
    # Ensure no duplicate IDs or conflicting styles/scripts (following project rules)
    existing_ids = set()
    existing_style_ids = set()
    existing_script_ids = set()
    
    for tag in soup.find_all(attrs={'id': True}):
        existing_ids.add(tag['id'])
        if tag.name == 'style':
            existing_style_ids.add(tag['id'])
        elif tag.name == 'script':
            existing_script_ids.add(tag['id'])
    
    # Update any generated elements with lp- prefix to avoid conflicts
    if isinstance(landing_div, Tag):
        for tag in landing_div.find_all(attrs={'id': True}):
            original_id = tag['id']
            if original_id in existing_ids:
                new_id = f"lp-{original_id}" if not original_id.startswith('lp-') else f"{original_id}-gen"
                tag['id'] = new_id
                logger.info(f"Updated conflicting ID: {original_id} -> {new_id}")
        
        # Ensure all CSS classes in the landing content use lp- prefix
        for tag in landing_div.find_all(attrs={'class': True}):
            if isinstance(tag, Tag):
                classes = tag.get('class', [])
                updated_classes = []
                for cls in classes:
                    if not cls.startswith('lp-') and not cls.startswith('btn') and not cls.startswith('fa-'):
                        updated_classes.append(f"lp-{cls}")
                    else:
                        updated_classes.append(cls)
                tag['class'] = updated_classes
    
    return str(soup)

@tracer.capture_method
def invalidate_cloudfront_cache(generation_id, cloudfront_domain):
    """Invalidate CloudFront cache for the generated content as per project rules."""
    try:
        if not cloudfront_domain:
            logger.warning("No CloudFront domain provided, skipping invalidation")
            return
        
        # Get the distribution ID from the domain
        distributions = cloudfront_client.list_distributions()
        distribution_id = None
        
        for dist in distributions.get('DistributionList', {}).get('Items', []):
            if dist.get('DomainName') == cloudfront_domain:
                distribution_id = dist.get('Id')
                break
        
        if not distribution_id:
            logger.warning(f"Could not find CloudFront distribution for domain: {cloudfront_domain}")
            return
        
        # Create invalidation for the specific generation path
        invalidation_paths = [f"/public/{generation_id}/*"]
        
        response = cloudfront_client.create_invalidation(
            DistributionId=distribution_id,
            InvalidationBatch={
                'Paths': {
                    'Quantity': len(invalidation_paths),
                    'Items': invalidation_paths
                },
                'CallerReference': f"laas-invalidation-{generation_id}-{int(time.time())}"
            }
        )
        
        logger.info(f"CloudFront invalidation created", extra={
            "invalidation_id": response['Invalidation']['Id'],
            "paths": invalidation_paths
        })
        
    except Exception as e:
        logger.error(f"Failed to invalidate CloudFront cache: {e}")
        # Don't fail the whole operation if invalidation fails

@tracer.capture_method
def store_final_html(final_html, bucket, generation_id, cloudfront_domain):
    """Store the final HTML in the public/ prefix and return the CloudFront URL."""
    
    # Store in public/ prefix
    public_key = f"public/{generation_id}/index.html"
    s3_client.put_object(
        Bucket=bucket,
        Key=public_key,
        Body=final_html.encode("utf-8"),
        ContentType="text/html",
        CacheControl="public, max-age=3600"
    )
    
    # Generate CloudFront URL
    if cloudfront_domain:
        public_url = f"https://{cloudfront_domain}/public/{generation_id}/index.html"
        
        # Invalidate CloudFront cache for this generation as per project rules
        invalidate_cloudfront_cache(generation_id, cloudfront_domain)
    else:
        # Fallback to S3 URL
        public_url = s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket, "Key": public_key},
            ExpiresIn=3600,
        )
    
    return public_url, public_key

@tracer.capture_method
def fetch_unsplash_image(query: str, target_width: int = 800, target_height: int = 600) -> str:
    """
    Fetch an image from Unsplash based on a search query.
    
    Args:
        query: Search query for the image
        target_width: Desired image width
        target_height: Desired image height
    
    Returns:
        Image URL from Unsplash
    """
    try:
        # Use Unsplash Source API (no API key required)
        # Format: https://source.unsplash.com/WIDTHxHEIGHT/?KEYWORDS
        encoded_query = urllib.parse.quote(query.replace(' ', ','))
        image_url = f"https://source.unsplash.com/{target_width}x{target_height}/?{encoded_query}"
        
        logger.info(f"Fetching Unsplash image", extra={
            "query": query,
            "url": image_url
        })
        
        return image_url
        
    except Exception as e:
        logger.error(f"Failed to fetch Unsplash image: {e}")
        # Return a placeholder image as fallback
        return f"https://via.placeholder.com/{target_width}x{target_height}/667eea/ffffff?text=Image"

@tracer.capture_method 
def process_image_prompts(img_prompts: List[str]) -> Dict[str, str]:
    """
    Process image prompts and return a mapping of image types to URLs.
    
    Args:
        img_prompts: List of image descriptions
    
    Returns:
        Dictionary mapping image types to URLs
    """
    image_urls = {}
    
    if not img_prompts:
        return image_urls
    
    # Map prompts to sections and fetch appropriate images
    for i, prompt in enumerate(img_prompts):
        if i == 0:
            # First image for hero section - wider format
            image_urls['hero'] = fetch_unsplash_image(prompt, 1200, 400)
        elif i == 1:
            # Second image for features section
            image_urls['feature1'] = fetch_unsplash_image(prompt, 400, 300)
        elif i == 2:
            # Third image for CTA section
            image_urls['cta'] = fetch_unsplash_image(prompt, 600, 400)
        elif i == 3:
            # Fourth image for another feature
            image_urls['feature2'] = fetch_unsplash_image(prompt, 400, 300)
    
    return image_urls

@tracer.capture_method
def enhance_html_with_images(html_content: str, image_urls: Dict[str, str]) -> str:
    """
    Enhance the generated HTML content with fetched images.
    
    Args:
        html_content: Original HTML content 
        image_urls: Dictionary of image URLs by type
    
    Returns:
        Enhanced HTML with images
    """
    if not image_urls:
        return html_content
    
    # Add hero background image
    if 'hero' in image_urls:
        html_content = html_content.replace(
            "class='lp-hero'",
            f"class='lp-hero' style='background-image: linear-gradient(rgba(102, 126, 234, 0.8), rgba(118, 75, 162, 0.8)), url({image_urls['hero']}); background-size: cover; background-position: center;'"
        )
    
    # Add feature images
    if 'feature1' in image_urls:
        html_content = html_content.replace(
            "<h3>Supply Chain Optimization</h3>",
            f"<img src='{image_urls['feature1']}' alt='Supply Chain Optimization' class='lp-feature-image'><h3>Supply Chain Optimization</h3>"
        )
    
    if 'feature2' in image_urls:
        html_content = html_content.replace(
            "<h3>Connected Vehicle Data</h3>",
            f"<img src='{image_urls['feature2']}' alt='Connected Vehicle Data' class='lp-feature-image'><h3>Connected Vehicle Data</h3>"
        )
    
    # Add CTA section image
    if 'cta' in image_urls:
        html_content = html_content.replace(
            "<div class='lp-cta-container'>",
            f"<div class='lp-cta-container'><img src='{image_urls['cta']}' alt='Digital Transformation' class='lp-cta-image'>"
        )
    
    return html_content

@logger.inject_lambda_context
@tracer.capture_lambda_handler
@metrics.log_metrics
def handler(event, context: LambdaContext):
    """Inject generated landing content into original HTML and store in public/ prefix."""
    
    logger.info("inject_html Lambda invoked", extra={"has_generation_id": bool(event.get('generation_id'))})
    
    # Environment variables
    bucket = os.environ["OUTPUT_BUCKET"]
    cloudfront_domain = os.environ.get("CLOUDFRONT_DOMAIN")
    
    try:
        # Parse input
        if "body" in event:
            body_content = event["body"]
            if event.get("isBase64Encoded"):
                body_content = base64.b64decode(body_content).decode("utf-8")
            parsed = json.loads(body_content)
        else:
            parsed = event if isinstance(event, dict) else json.loads(event)
        
        generation_id = parsed.get('generation_id')
        s3_keys = parsed.get('s3_keys', {})
        
        if not generation_id:
            return {
                "statusCode": 400,
                "headers": CORS_HEADERS,
                "body": json.dumps({"error": "Missing generation_id parameter"})
            }
        
        # Retrieve the original HTML and generated content from S3
        original_html_key = s3_keys.get('original_html')
        rewritten_html_key = s3_keys.get('rewritten_html')
        content_key = f"generated/{generation_id}/landing_content.json"
        theme_key = f"generated/{generation_id}/theme_info.json"
        
        if not original_html_key:
            return {
                "statusCode": 400,
                "headers": CORS_HEADERS,
                "body": json.dumps({"error": "Missing original_html S3 key"})
            }
        
        # Get the original HTML
        original_html = get_s3_object(bucket, original_html_key)
        
        # Get the generated landing content
        try:
            landing_content = json.loads(get_s3_object(bucket, content_key))
        except Exception as e:
            logger.warning(f"Could not retrieve landing content, using empty content: {e}")
            landing_content = {
                'hero_html': '<div class="lp-hero"><h1>Generated Landing Page</h1></div>',
                'features_html': '<div class="lp-features"><p>Features will be generated here</p></div>',
                'cta_html': '<div class="lp-cta"><button>Get Started</button></div>'
            }
        
        # Get theme info
        try:
            theme_info = json.loads(get_s3_object(bucket, theme_key))
        except Exception as e:
            logger.warning(f"Could not retrieve theme info, using defaults: {e}")
            theme_info = {}
        
        # Process image prompts and fetch images
        img_prompts = landing_content.get('img_prompts', [])
        image_urls = process_image_prompts(img_prompts)
        logger.info(f"Processed {len(img_prompts)} image prompts", extra={
            "generation_id": generation_id,
            "image_count": len(image_urls)
        })
        
        # Enhance landing content with images
        if image_urls:
            for key in ['hero_html', 'features_html', 'cta_html']:
                if key in landing_content:
                    landing_content[key] = enhance_html_with_images(landing_content[key], image_urls)
        
        # Inject landing content into original HTML
        final_html = inject_landing_into_html(original_html, landing_content, theme_info)
        
        # Store final HTML in public/ prefix
        public_url, public_key = store_final_html(final_html, bucket, generation_id, cloudfront_domain)
        
        # Return the public URL
        result = {
            "htmlUrl": public_url,
            "generation_id": generation_id,
            "public_key": public_key,
            "status": "injected"
        }
        
        logger.info("HTML injection completed successfully", extra={
            "generation_id": generation_id,
            "public_url": public_url
        })
        
        return {
            "statusCode": 200,
            "headers": CORS_HEADERS,
            "body": json.dumps(result)
        }
        
    except Exception as e:
        logger.error("Error in inject_html Lambda", extra={"error": str(e), "traceback": str(e.__traceback__)})
        return {
            "statusCode": 500,
            "headers": CORS_HEADERS,
            "body": json.dumps({"error": f"Injection failed: {str(e)}"})
        } 