"""Pydantic models for data validation in the inject_html Lambda."""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field, validator


class ThemeInfo(BaseModel):
    """Theme information for HTML injection."""
    
    fonts: Optional[List[str]] = Field(default_factory=list, description="List of fonts to use")
    color_palette: Optional[List[str]] = Field(default_factory=list, description="Color palette for styling")
    logo_url: Optional[str] = Field(None, description="URL of the site's logo")
    inline_styles: Optional[List[str]] = Field(default_factory=list, description="CSS styles to inject")
    
    @validator('fonts')
    def validate_fonts(cls, v):
        """Ensure fonts are valid."""
        if v is None:
            return []
        return [font.strip() for font in v if font and font.strip()]
    
    @validator('color_palette')
    def validate_colors(cls, v):
        """Ensure colors are valid."""
        if v is None:
            return []
        valid_colors = []
        for color in v:
            if color and isinstance(color, str):
                color = color.strip()
                if color.startswith('#') or color.startswith('rgb') or color.startswith('hsl'):
                    valid_colors.append(color)
        return valid_colors


class LandingContent(BaseModel):
    """Landing page content to inject."""
    
    hero_html: str = Field(..., description="Hero section HTML")
    features_html: str = Field(..., description="Features section HTML")
    cta_html: str = Field(..., description="Call-to-action HTML")
    img_prompts: Optional[List[str]] = Field(default_factory=list, description="Image prompts")
    
    @validator('hero_html', 'features_html', 'cta_html')
    def validate_html_content(cls, v):
        """Ensure HTML content is valid."""
        if not v or not v.strip():
            return ""
        
        # Basic HTML sanitization
        import re
        
        # Remove script tags
        v = re.sub(r'<script[^>]*>.*?</script>', '', v, flags=re.IGNORECASE | re.DOTALL)
        
        # Remove javascript: URLs
        v = re.sub(r'javascript:', '', v, flags=re.IGNORECASE)
        
        # Remove on* event handlers
        v = re.sub(r'\s+on\w+\s*=\s*["\'][^"\']*["\']', '', v, flags=re.IGNORECASE)
        
        return v.strip()


class S3Event(BaseModel):
    """S3 event record structure."""
    
    bucket_name: str = Field(..., description="S3 bucket name")
    object_key: str = Field(..., description="S3 object key")
    
    @validator('bucket_name', 'object_key')
    def validate_s3_params(cls, v):
        """Ensure S3 parameters are valid."""
        if not v or not v.strip():
            raise ValueError("S3 parameters cannot be empty")
        return v.strip()


class InjectionRequest(BaseModel):
    """Complete injection request structure."""
    
    s3_event: S3Event = Field(..., description="S3 event information")
    landing_content: LandingContent = Field(..., description="Landing content to inject")
    theme_info: Optional[ThemeInfo] = Field(default_factory=ThemeInfo, description="Theme information")
    generation_id: Optional[str] = Field(None, description="Generation ID for tracking")
    
    @validator('generation_id')
    def validate_generation_id(cls, v):
        """Ensure generation ID is valid UUID format."""
        if v is None:
            return None
        
        import uuid
        try:
            uuid.UUID(v)
            return v
        except ValueError:
            raise ValueError("Generation ID must be a valid UUID")


class InjectionResponse(BaseModel):
    """Response structure for HTML injection."""
    
    status: str = Field(..., description="Injection status")
    public_url: Optional[str] = Field(None, description="Public URL of the injected content")
    generation_id: Optional[str] = Field(None, description="Generation ID")
    assets: Optional[Dict[str, str]] = Field(default_factory=dict, description="Generated assets")
    
    @validator('status')
    def validate_status(cls, v):
        """Ensure status is valid."""
        valid_statuses = ['injected', 'failed', 'in_progress']
        if v not in valid_statuses:
            raise ValueError(f"Status must be one of: {valid_statuses}")
        return v


class CloudFrontInvalidation(BaseModel):
    """CloudFront invalidation information."""
    
    distribution_id: str = Field(..., description="CloudFront distribution ID")
    paths: List[str] = Field(..., description="Paths to invalidate")
    caller_reference: str = Field(..., description="Unique caller reference")
    
    @validator('paths')
    def validate_paths(cls, v):
        """Ensure paths are valid."""
        if not v:
            raise ValueError("Paths list cannot be empty")
        
        valid_paths = []
        for path in v:
            if path and isinstance(path, str):
                if not path.startswith('/'):
                    path = '/' + path
                valid_paths.append(path)
        
        return valid_paths if valid_paths else ['/'] 